﻿namespace FinalProj_personnel
{
    partial class FormSearchApproval
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonreturn = new System.Windows.Forms.Button();
            this.textBoxreturn = new System.Windows.Forms.TextBox();
            this.labelreturn = new System.Windows.Forms.Label();
            this.textBoxappr_work = new System.Windows.Forms.TextBox();
            this.buttonappr = new System.Windows.Forms.Button();
            this.textBoxappr_text = new System.Windows.Forms.TextBox();
            this.labelappr_name = new System.Windows.Forms.Label();
            this.textBoxappr_comment = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxappr_name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxSearch = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxsearch_step = new System.Windows.Forms.ComboBox();
            this.buttonstep_next = new System.Windows.Forms.Button();
            this.buttonsearch_step = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxSearch_work = new System.Windows.Forms.GroupBox();
            this.comboBoxsearch_work = new System.Windows.Forms.ComboBox();
            this.buttonwork_next = new System.Windows.Forms.Button();
            this.buttonsearch_work = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.labelsearch_work = new System.Windows.Forms.Label();
            this.groupBoxSarch_name = new System.Windows.Forms.GroupBox();
            this.buttonname_next = new System.Windows.Forms.Button();
            this.buttonsearch_name = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBoxsaerch_name = new System.Windows.Forms.TextBox();
            this.labelSeach_name = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBoxSearch.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBoxSearch_work.SuspendLayout();
            this.groupBoxSarch_name.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonreturn);
            this.groupBox2.Controls.Add(this.textBoxreturn);
            this.groupBox2.Controls.Add(this.labelreturn);
            this.groupBox2.Controls.Add(this.textBoxappr_work);
            this.groupBox2.Controls.Add(this.buttonappr);
            this.groupBox2.Controls.Add(this.textBoxappr_text);
            this.groupBox2.Controls.Add(this.labelappr_name);
            this.groupBox2.Controls.Add(this.textBoxappr_comment);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBoxappr_name);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(691, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(323, 509);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "결재";
            // 
            // buttonreturn
            // 
            this.buttonreturn.Location = new System.Drawing.Point(184, 443);
            this.buttonreturn.Name = "buttonreturn";
            this.buttonreturn.Size = new System.Drawing.Size(101, 31);
            this.buttonreturn.TabIndex = 24;
            this.buttonreturn.Text = "결재 반려";
            this.buttonreturn.UseVisualStyleBackColor = true;
            // 
            // textBoxreturn
            // 
            this.textBoxreturn.Location = new System.Drawing.Point(127, 405);
            this.textBoxreturn.Name = "textBoxreturn";
            this.textBoxreturn.Size = new System.Drawing.Size(158, 21);
            this.textBoxreturn.TabIndex = 23;
            // 
            // labelreturn
            // 
            this.labelreturn.AutoSize = true;
            this.labelreturn.Location = new System.Drawing.Point(22, 408);
            this.labelreturn.Name = "labelreturn";
            this.labelreturn.Size = new System.Drawing.Size(69, 12);
            this.labelreturn.TabIndex = 22;
            this.labelreturn.Text = "반려 코멘트";
            // 
            // textBoxappr_work
            // 
            this.textBoxappr_work.Location = new System.Drawing.Point(127, 60);
            this.textBoxappr_work.Name = "textBoxappr_work";
            this.textBoxappr_work.Size = new System.Drawing.Size(158, 21);
            this.textBoxappr_work.TabIndex = 21;
            // 
            // buttonappr
            // 
            this.buttonappr.Location = new System.Drawing.Point(184, 346);
            this.buttonappr.Name = "buttonappr";
            this.buttonappr.Size = new System.Drawing.Size(101, 31);
            this.buttonappr.TabIndex = 20;
            this.buttonappr.Text = "결재 승인";
            this.buttonappr.UseVisualStyleBackColor = true;
            // 
            // textBoxappr_text
            // 
            this.textBoxappr_text.Location = new System.Drawing.Point(127, 107);
            this.textBoxappr_text.Multiline = true;
            this.textBoxappr_text.Name = "textBoxappr_text";
            this.textBoxappr_text.Size = new System.Drawing.Size(158, 185);
            this.textBoxappr_text.TabIndex = 17;
            // 
            // labelappr_name
            // 
            this.labelappr_name.AutoSize = true;
            this.labelappr_name.Location = new System.Drawing.Point(22, 23);
            this.labelappr_name.Name = "labelappr_name";
            this.labelappr_name.Size = new System.Drawing.Size(57, 12);
            this.labelappr_name.TabIndex = 12;
            this.labelappr_name.Text = "결재 제목";
            // 
            // textBoxappr_comment
            // 
            this.textBoxappr_comment.Location = new System.Drawing.Point(127, 309);
            this.textBoxappr_comment.Name = "textBoxappr_comment";
            this.textBoxappr_comment.Size = new System.Drawing.Size(158, 21);
            this.textBoxappr_comment.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 13;
            this.label4.Text = "관련 업무";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 12);
            this.label3.TabIndex = 14;
            this.label3.Text = "결재 내용";
            // 
            // textBoxappr_name
            // 
            this.textBoxappr_name.Location = new System.Drawing.Point(127, 20);
            this.textBoxappr_name.Name = "textBoxappr_name";
            this.textBoxappr_name.Size = new System.Drawing.Size(158, 21);
            this.textBoxappr_name.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 312);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "결재 코멘트";
            // 
            // groupBoxSearch
            // 
            this.groupBoxSearch.Controls.Add(this.groupBox3);
            this.groupBoxSearch.Controls.Add(this.groupBox1);
            this.groupBoxSearch.Controls.Add(this.groupBoxSearch_work);
            this.groupBoxSearch.Controls.Add(this.groupBoxSarch_name);
            this.groupBoxSearch.Location = new System.Drawing.Point(15, 12);
            this.groupBoxSearch.Name = "groupBoxSearch";
            this.groupBoxSearch.Size = new System.Drawing.Size(670, 602);
            this.groupBoxSearch.TabIndex = 5;
            this.groupBoxSearch.TabStop = false;
            this.groupBoxSearch.Text = "결재 검색";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBoxsearch_step);
            this.groupBox1.Controls.Add(this.buttonstep_next);
            this.groupBox1.Controls.Add(this.buttonsearch_step);
            this.groupBox1.Controls.Add(this.listBox3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(334, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 281);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "단계별 검색";
            // 
            // comboBoxsearch_step
            // 
            this.comboBoxsearch_step.FormattingEnabled = true;
            this.comboBoxsearch_step.Location = new System.Drawing.Point(88, 18);
            this.comboBoxsearch_step.Name = "comboBoxsearch_step";
            this.comboBoxsearch_step.Size = new System.Drawing.Size(144, 20);
            this.comboBoxsearch_step.TabIndex = 17;
            // 
            // buttonstep_next
            // 
            this.buttonstep_next.Location = new System.Drawing.Point(245, 45);
            this.buttonstep_next.Name = "buttonstep_next";
            this.buttonstep_next.Size = new System.Drawing.Size(59, 23);
            this.buttonstep_next.TabIndex = 16;
            this.buttonstep_next.Text = "자세히";
            this.buttonstep_next.UseVisualStyleBackColor = true;
            // 
            // buttonsearch_step
            // 
            this.buttonsearch_step.Location = new System.Drawing.Point(245, 18);
            this.buttonsearch_step.Name = "buttonsearch_step";
            this.buttonsearch_step.Size = new System.Drawing.Size(59, 23);
            this.buttonsearch_step.TabIndex = 15;
            this.buttonsearch_step.Text = "검색";
            this.buttonsearch_step.UseVisualStyleBackColor = true;
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 12;
            this.listBox3.Location = new System.Drawing.Point(17, 47);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(215, 220);
            this.listBox3.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 12;
            this.label1.Text = "진행 단계";
            // 
            // groupBoxSearch_work
            // 
            this.groupBoxSearch_work.Controls.Add(this.comboBoxsearch_work);
            this.groupBoxSearch_work.Controls.Add(this.buttonwork_next);
            this.groupBoxSearch_work.Controls.Add(this.buttonsearch_work);
            this.groupBoxSearch_work.Controls.Add(this.listBox2);
            this.groupBoxSearch_work.Controls.Add(this.labelsearch_work);
            this.groupBoxSearch_work.Location = new System.Drawing.Point(7, 312);
            this.groupBoxSearch_work.Name = "groupBoxSearch_work";
            this.groupBoxSearch_work.Size = new System.Drawing.Size(310, 281);
            this.groupBoxSearch_work.TabIndex = 17;
            this.groupBoxSearch_work.TabStop = false;
            this.groupBoxSearch_work.Text = "업무별 검색";
            // 
            // comboBoxsearch_work
            // 
            this.comboBoxsearch_work.FormattingEnabled = true;
            this.comboBoxsearch_work.Location = new System.Drawing.Point(88, 20);
            this.comboBoxsearch_work.Name = "comboBoxsearch_work";
            this.comboBoxsearch_work.Size = new System.Drawing.Size(144, 20);
            this.comboBoxsearch_work.TabIndex = 12;
            // 
            // buttonwork_next
            // 
            this.buttonwork_next.Location = new System.Drawing.Point(245, 45);
            this.buttonwork_next.Name = "buttonwork_next";
            this.buttonwork_next.Size = new System.Drawing.Size(59, 23);
            this.buttonwork_next.TabIndex = 16;
            this.buttonwork_next.Text = "자세히";
            this.buttonwork_next.UseVisualStyleBackColor = true;
            // 
            // buttonsearch_work
            // 
            this.buttonsearch_work.Location = new System.Drawing.Point(245, 18);
            this.buttonsearch_work.Name = "buttonsearch_work";
            this.buttonsearch_work.Size = new System.Drawing.Size(59, 23);
            this.buttonsearch_work.TabIndex = 15;
            this.buttonsearch_work.Text = "검색";
            this.buttonsearch_work.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(17, 47);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(215, 220);
            this.listBox2.TabIndex = 14;
            // 
            // labelsearch_work
            // 
            this.labelsearch_work.AutoSize = true;
            this.labelsearch_work.Location = new System.Drawing.Point(15, 23);
            this.labelsearch_work.Name = "labelsearch_work";
            this.labelsearch_work.Size = new System.Drawing.Size(57, 12);
            this.labelsearch_work.TabIndex = 12;
            this.labelsearch_work.Text = "관련 업무";
            // 
            // groupBoxSarch_name
            // 
            this.groupBoxSarch_name.Controls.Add(this.buttonname_next);
            this.groupBoxSarch_name.Controls.Add(this.buttonsearch_name);
            this.groupBoxSarch_name.Controls.Add(this.listBox1);
            this.groupBoxSarch_name.Controls.Add(this.textBoxsaerch_name);
            this.groupBoxSarch_name.Controls.Add(this.labelSeach_name);
            this.groupBoxSarch_name.Location = new System.Drawing.Point(7, 21);
            this.groupBoxSarch_name.Name = "groupBoxSarch_name";
            this.groupBoxSarch_name.Size = new System.Drawing.Size(310, 283);
            this.groupBoxSarch_name.TabIndex = 0;
            this.groupBoxSarch_name.TabStop = false;
            this.groupBoxSarch_name.Text = "제목별 검색";
            // 
            // buttonname_next
            // 
            this.buttonname_next.Location = new System.Drawing.Point(245, 45);
            this.buttonname_next.Name = "buttonname_next";
            this.buttonname_next.Size = new System.Drawing.Size(59, 23);
            this.buttonname_next.TabIndex = 16;
            this.buttonname_next.Text = "자세히";
            this.buttonname_next.UseVisualStyleBackColor = true;
            // 
            // buttonsearch_name
            // 
            this.buttonsearch_name.Location = new System.Drawing.Point(245, 18);
            this.buttonsearch_name.Name = "buttonsearch_name";
            this.buttonsearch_name.Size = new System.Drawing.Size(59, 23);
            this.buttonsearch_name.TabIndex = 15;
            this.buttonsearch_name.Text = "검색";
            this.buttonsearch_name.UseVisualStyleBackColor = true;
            this.buttonsearch_name.Click += new System.EventHandler(this.buttonsearch_name_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(17, 51);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(215, 220);
            this.listBox1.TabIndex = 14;
            // 
            // textBoxsaerch_name
            // 
            this.textBoxsaerch_name.Location = new System.Drawing.Point(88, 20);
            this.textBoxsaerch_name.Name = "textBoxsaerch_name";
            this.textBoxsaerch_name.Size = new System.Drawing.Size(144, 21);
            this.textBoxsaerch_name.TabIndex = 13;
            // 
            // labelSeach_name
            // 
            this.labelSeach_name.AutoSize = true;
            this.labelSeach_name.Location = new System.Drawing.Point(15, 23);
            this.labelSeach_name.Name = "labelSeach_name";
            this.labelSeach_name.Size = new System.Drawing.Size(57, 12);
            this.labelSeach_name.TabIndex = 12;
            this.labelSeach_name.Text = "결재 제목";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.listBox4);
            this.groupBox3.Location = new System.Drawing.Point(334, 317);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(310, 276);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "내 결재 검색";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(245, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "자세히";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(245, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(59, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "검색";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 12;
            this.listBox4.Location = new System.Drawing.Point(17, 47);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(215, 220);
            this.listBox4.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(135, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 12);
            this.label5.TabIndex = 17;
            this.label5.Text = "내 결재 검색하기";
            // 
            // FormSearchApproval
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1046, 640);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBoxSearch);
            this.Name = "FormSearchApproval";
            this.Text = "FormSearchApproval";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBoxSearch.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxSearch_work.ResumeLayout(false);
            this.groupBoxSearch_work.PerformLayout();
            this.groupBoxSarch_name.ResumeLayout(false);
            this.groupBoxSarch_name.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonreturn;
        private System.Windows.Forms.TextBox textBoxreturn;
        private System.Windows.Forms.Label labelreturn;
        private System.Windows.Forms.TextBox textBoxappr_work;
        private System.Windows.Forms.Button buttonappr;
        private System.Windows.Forms.TextBox textBoxappr_text;
        private System.Windows.Forms.Label labelappr_name;
        private System.Windows.Forms.TextBox textBoxappr_comment;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxappr_name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBoxsearch_step;
        private System.Windows.Forms.Button buttonstep_next;
        private System.Windows.Forms.Button buttonsearch_step;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxSearch_work;
        private System.Windows.Forms.ComboBox comboBoxsearch_work;
        private System.Windows.Forms.Button buttonwork_next;
        private System.Windows.Forms.Button buttonsearch_work;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label labelsearch_work;
        private System.Windows.Forms.GroupBox groupBoxSarch_name;
        private System.Windows.Forms.Button buttonname_next;
        private System.Windows.Forms.Button buttonsearch_name;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBoxsaerch_name;
        private System.Windows.Forms.Label labelSeach_name;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Label label5;
    }
}