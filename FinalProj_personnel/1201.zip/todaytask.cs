﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task
{
    class todaytask
    {
        public string name { get; set; }
        public string name2 { get; set; }
        public string name3 { get; set; }

        public string num1 { get; set; }
        public todaytask(string task)
        {
            this.name = name;
            this.name2 = name2;
            this.name3 = name3;
            this.num1 = num1;
        }
    }
}
